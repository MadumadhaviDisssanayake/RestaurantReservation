package PrintBill;


import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import UpdateBooking.Update;

public class Print {

	private JFrame frame;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel1;
	private JLabel lblNewLabel11;
	private JLabel lblNewLabel3;
	private JLabel lblNewLabel4;
	private JLabel lblNewLabel5;
	private JLabel lblNewLabel6;
	private JLabel lblNewLabel7;
	private JLabel lblNewLabel8;
	private JLabel lblNewLabel9;
	private JLabel lblNewLabel10;
	private JLabel lblNewLabel15;
	private JLabel lblNewLabel12;
	private JLabel lblNewLabel13;
	private JLabel lblNewLabel14;
	private JPanel panel;
	private JPanel panel2;
	private JPanel panel3;
	
	private JTextField txtName;
	private JTextField txtContact;
	private JTextField txtAddress;
	private JComboBox comboBox_6_2;
	private JTextField textField;
	private JTextField textField1;
	
	private JLabel lblNewLabel2;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Print window = new Print();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	/**
	 * Create the application.
	 */
	public Print() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 1426, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Component horizontalGlue = Box.createHorizontalGlue();
		horizontalGlue.setBounds(38, 106, 1, 1);
		horizontalGlue.setBackground(Color.RED);
		frame.getContentPane().add(horizontalGlue);
		
		lblNewLabel = new JLabel("GUEST INFO & PAYMENTS");
		
		lblNewLabel.setBounds(35, 13, 500, 116);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel.setForeground(Color.MAGENTA);
		frame.getContentPane().add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBounds(110, 100, 1200, 200);
		panel.setBorder(new LineBorder(Color.BLUE, 5, true));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
	
		lblNewLabel1 = new JLabel("Name");
		
		lblNewLabel1.setBounds(30, 10, 500, 30);
		lblNewLabel1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel1.setForeground(Color.BLACK);
		panel.add(lblNewLabel1);
		
		lblNewLabel2 = new JLabel("Contact Number");
		
		lblNewLabel2.setBounds(30, 50, 500, 30);
		lblNewLabel2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel2.setForeground(Color.BLACK);
		panel.add(lblNewLabel2);
		
		lblNewLabel11 = new JLabel("Address");
		
		lblNewLabel11.setBounds(30, 90, 500, 30);
		lblNewLabel11.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel11.setForeground(Color.BLACK);
		panel.add(lblNewLabel11);
		
		
		txtName = new JTextField();
		txtName.setBounds(190, 10, 900, 34);
		txtName.setBackground(Color.WHITE);
		txtName.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 23));
		txtName.setForeground(Color.BLUE);
		txtName.setText("Name");
		panel.add(txtName);
		txtName.setColumns(10);
		
		txtContact = new JTextField();
		txtContact.setBounds(190, 50, 900, 34);
		txtContact.setBackground(Color.WHITE);
		txtContact.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 23));
		txtContact.setForeground(Color.BLUE);
		txtContact.setText("Mobile Number");
		panel.add(txtContact);
		txtContact.setColumns(10);
		
		txtAddress = new JTextField();
		txtAddress.setBounds(190, 90, 900, 100);
		txtAddress.setBackground(Color.WHITE);
		txtAddress.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 23));
		txtAddress.setForeground(Color.BLUE);
		txtAddress.setText("Address");
		panel.add(txtAddress);
		txtAddress.setColumns(10);
		
		lblNewLabel3 = new JLabel("Search Again");
		
		lblNewLabel3.setBounds(30, 300, 500, 30);
		lblNewLabel3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel3.setForeground(Color.BLACK);
		frame.add(lblNewLabel3);
		
		
		panel2 = new JPanel();
		panel2.setBounds(110, 350, 1200, 100);
		panel2.setBorder(new LineBorder(Color.BLUE, 5, true));
		frame.getContentPane().add(panel2);
		panel2.setLayout(null);
		
		
		lblNewLabel4 = new JLabel("POOL");
		
		lblNewLabel4.setBounds(30, 10, 500, 30);
		lblNewLabel4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel4.setForeground(Color.BLACK);
		panel2.add(lblNewLabel4);
		
		lblNewLabel5 = new JLabel("Children");
		
		lblNewLabel5.setBounds(30, 30, 500, 30);
		lblNewLabel5.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel5.setForeground(Color.BLACK);
		panel2.add(lblNewLabel5);
		
		lblNewLabel6 = new JLabel("1");
		
		lblNewLabel6.setBounds(150, 30, 500, 30);
		lblNewLabel6.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel6.setForeground(Color.BLACK);
		panel2.add(lblNewLabel6);
		
		lblNewLabel7 = new JLabel("Adults");
		
		lblNewLabel7.setBounds(30, 50, 500, 30);
		lblNewLabel7.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel7.setForeground(Color.BLACK);
		panel2.add(lblNewLabel7);
		
		lblNewLabel8 = new JLabel("2");
		
		lblNewLabel8.setBounds(150, 50, 500, 30);
		lblNewLabel8.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel8.setForeground(Color.BLACK);
		panel2.add(lblNewLabel8);
		
		
		panel3 = new JPanel();
		panel3.setBounds(110, 500, 1200, 200);
		panel3.setBorder(new LineBorder(Color.BLUE, 5, true));
		frame.getContentPane().add(panel3);
		panel3.setLayout(null);
		
		lblNewLabel9 = new JLabel("Total Pool Rate :");
		
		lblNewLabel9.setBounds(30, 10, 500, 30);
		lblNewLabel9.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel9.setForeground(Color.BLACK);
		panel3.add(lblNewLabel9);
		
		lblNewLabel10 = new JLabel("Tax  :");
		
		lblNewLabel10.setBounds(30, 50, 500, 30);
		lblNewLabel10.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel10.setForeground(Color.BLACK);
		panel3.add(lblNewLabel10);
		
		
		lblNewLabel12 = new JLabel("Total :");
		
		lblNewLabel12.setBounds(30, 100, 500, 30);
		lblNewLabel12.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel12.setForeground(Color.BLACK);
		panel3.add(lblNewLabel12);
		
		
		
		
		
		lblNewLabel13 = new JLabel("USD 102");
		
		lblNewLabel13.setBounds(180, 10, 500, 30);
		lblNewLabel13.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel13.setForeground(Color.BLACK);
		panel3.add(lblNewLabel13);
		
		lblNewLabel14 = new JLabel("USD 11");
		
		lblNewLabel14.setBounds(180, 50, 500, 30);
		lblNewLabel14.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel14.setForeground(Color.BLACK);
		panel3.add(lblNewLabel14);
		
		
		lblNewLabel15 = new JLabel("USD 113 ");
		
		lblNewLabel15.setBounds(180, 100, 500, 30);
		lblNewLabel15.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel15.setForeground(Color.BLACK);
		panel3.add(lblNewLabel15);
		
		
		
		JButton btnNewButton = new JButton("PRINT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed1(ActionEvent arg0) {
				
				 Print newPrint=new Print();
				Print.main(null);
				
			}

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton.setBounds(500, 763, 500, 47);
		frame.getContentPane().add(btnNewButton);
		
	}

}
