package Booknow;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import Calculate.Cal;

public class Book {
	
	private JFrame frame;
	private JLabel lblNewLabel;
	private JPanel panel;
	private JPanel panel1;
	private JPanel panel11;
	private JPanel panel2;
	private JTextField txtFastFoodItems;
	
	private JTextField txtFood;
	private JTextField txtQuantity;
	private JComboBox comboBox_6_2;
	private JComboBox comboBox2;
	private JComboBox comboBox3;
	private JComboBox comboBox4;
	private Checkbox checkbox_1;
	
	private JLabel lblNewLabel2;
	private JLabel lblNewLabel3;
	private JLabel lblNewLabel4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Book window = new Book();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	public Book() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 1426, 870);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Component horizontalGlue = Box.createHorizontalGlue();
		horizontalGlue.setBounds(38, 106, 1, 1);
		horizontalGlue.setBackground(Color.RED);
		frame.getContentPane().add(horizontalGlue);
		
		lblNewLabel = new JLabel("Available Halls,Tables and Pool");
		
		lblNewLabel.setBounds(200, 13, 426, 116);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setForeground(Color.RED);
		frame.getContentPane().add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBounds(110, 100, 1200, 600);
		panel.setBorder(new LineBorder(Color.CYAN, 5, true));
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		panel1 = new JPanel();
		panel1.setBounds(30, 100, 1100, 50);
		panel1.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel1);
		panel1.setLayout(null);
		
		lblNewLabel2 = new JLabel("Hall Rates");
		
		lblNewLabel2.setBounds(30, 13, 100, 11);
		lblNewLabel2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel2.setForeground(Color.RED);
		panel1.add(lblNewLabel2);
		
		
		comboBox_6_2 = new JComboBox();
		comboBox_6_2.setModel(new DefaultComboBoxModel(new String[] {"View Rates", "$120", "$300", "$99", "$59", "$100"}));
		comboBox_6_2.setBounds(30, 150, 1100, 50);
		panel.add(comboBox_6_2);
		
		
		
		panel11 = new JPanel();
		panel11.setBounds(30, 250, 1100, 50);
		panel11.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel11);
		panel11.setLayout(null);
		
		lblNewLabel3 = new JLabel("Table Reservation");
		
		lblNewLabel3.setBounds(30, 13, 150, 11);
		lblNewLabel3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel3.setForeground(Color.RED);
		panel11.add(lblNewLabel3);
		
		
		comboBox3 = new JComboBox();
		comboBox3.setModel(new DefaultComboBoxModel(new String[] {"View Rates", "$120", "$300", "$99", "$59", "$100"}));
		comboBox3.setBounds(30, 300, 1100, 50);
		panel.add(comboBox3);
		
		
		
		panel2 = new JPanel();
		panel2.setBounds(30, 400, 1100, 50);
		panel2.setBorder(new LineBorder(Color.BLACK, 5, true));
		panel.add(panel2);
		panel2.setLayout(null);
		
		lblNewLabel4 = new JLabel("Pool Rates");
		
		lblNewLabel4.setBounds(30, 13, 150, 11);
		lblNewLabel4.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel4.setForeground(Color.RED);
		panel2.add(lblNewLabel4);
		
		
		comboBox4 = new JComboBox();
		comboBox4.setModel(new DefaultComboBoxModel(new String[] {"View Rates", "$120", "$300", "$99", "$59", "$100"}));
		comboBox4.setBounds(30, 450, 1100, 50);
		panel.add(comboBox4);
		
		
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			//public void actionPerformed1(ActionEvent arg0) {
				
				
				
			//}

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				Cal newCal=new Cal();
				Cal.main(null);
				// TODO Auto-generated method stub
				
			}
		});
		
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnNewButton.setBounds(500, 763, 400, 47);
		frame.getContentPane().add(btnNewButton);
		
		
		
		
}
	
	
	
}

